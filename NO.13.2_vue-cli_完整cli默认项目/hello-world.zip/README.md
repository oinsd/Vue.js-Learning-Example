# hello-world

## Project setup
```
cnpm install
```

### Compiles and hot-reloads for development
```
cnpm run serve
```

### Compiles and minifies for production
```
cnpm run build
```

### Lints and fixes files
```
cnpm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
