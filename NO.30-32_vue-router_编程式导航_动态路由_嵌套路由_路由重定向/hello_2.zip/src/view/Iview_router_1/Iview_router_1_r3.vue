<template>
    <div>
        'contentBar3'组件，对应的vue文件名：Iview_router_1_r3
    </div>
</template>