<template>
  <div id="app">
    <HW msg="Vue-Cli"/>
  </div>
</template>

<script>
import HW from './components/HelloWorld.vue'

export default 
{
  name: 'App',
  components: 
  {
    HW
  }
}
</script>

<style>
</style>
