<template>
  <div>
    <slot></slot>(aBar)
  </div>
</template>

<script>
export default 
{
  name: 'aBar',
  //  不要使用下划线命名 a_Bar,因为要在标签中使用
}
</script>

<style>
</style>
