import Vue from 'vue'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';

import App from './App_Layout_Container.vue' // Layout_Container 布局 + 容器
// import App from './App_form.vue' // Form 表单 + 布局 + Card 卡片
// import App from './App_form_2.vue' // Form 表单 + 布局 + Card 卡片 + 验证
// import App from './app_test.vue'


Vue.config.productionTip = false

Vue.use(ElementUI);

new Vue
(
  {
    render: h => h(App),
  }
).$mount('#app')
