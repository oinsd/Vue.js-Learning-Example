<template>
  <div id="app">
    <h1>666666</h1>
  </div>
</template>

<script>
import Vue from 'vue';

  export default {
    // name:'App',
  };
</script>

<style>
</style>
测试结论：如果只有一个export default，将默认被认为一个名字
在main.js里面，导入，无论啥名字，都行，App,xxx都行