# hello-world

## element-ui install

cnpm i element-ui -S

## Project setup
```
cnpm install
```

### Compiles and hot-reloads for development
```
cnpm run serve
```

### Compiles and minifies for production
```
cnpm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).


